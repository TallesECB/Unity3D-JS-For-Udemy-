﻿#pragma strict

var rb: Rigidbody;


function Start () {
	rb = transform.GetComponent(Rigidbody);	
}

function Update () {
	rb.velocity = transform.forward*100;
}
