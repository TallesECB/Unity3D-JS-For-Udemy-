﻿#pragma strict

var vel: float;
var vellateral: float;
var velsubir: float;
var helice: Transform;
var velrotacao: float; 

function Start () {
	vel = 500*Time.deltaTime;
	vellateral = 20*Time.deltaTime;
	velsubir = 40*Time.deltaTime;
	velrotacao = 20*Time.deltaTime;
}

function Update () {

	helice.Rotate(0, 500*Time.deltaTime, 0);

	//movimentação profundidade eixo y
	if(Input.GetKey(KeyCode.W)) {
		transform.Translate(0, 0, vel);
	}
	else {
		if(Input.GetKey(KeyCode.S)) {
			transform.Translate(0, 0, -vel);
		}
	}

	//movimentação lateral eixo x
	if(Input.GetKey(KeyCode.A)) {
		transform.Translate(-vellateral, 0, 0);
	}
	else {
		if(Input.GetKey(KeyCode.D)) {
			transform.Translate(vellateral, 0, 0);
		}
	}

	//movimentação para baixo e para cima
	if(Input.GetKey(KeyCode.Space)) {
		transform.Translate(0, velsubir, 0);
	}
	else {
		if(Input.GetKey(KeyCode.Z)) {
			transform.Translate(0, -velsubir, 0);
		}
	}

	//rotacionando objeto com o mouse
	if(Input.GetMouseButton(0)) {
		transform.Rotate(0, -velrotacao, 0);
	}
	else {
		if(Input.GetMouseButton(1)) {
			transform.Rotate(0, velrotacao, 0);
		}
	}
}
