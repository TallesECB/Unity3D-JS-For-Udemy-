﻿#pragma strict

function Start () {
	
}

function Update () {
	//transform.Rotate(0, 10, 0);	//x,y,z
	//comando rotate executando nas variaveis diretamente na esfera/helice.
}
