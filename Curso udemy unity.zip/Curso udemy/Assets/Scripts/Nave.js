﻿#pragma strict

function Start () {
	
}

function Update () {
	//transform.Translate(0, 0, 0.2); 
	// o translate da nave, ficou no variaveis, executando com velocidade alternada diretamente no unity
	
}
