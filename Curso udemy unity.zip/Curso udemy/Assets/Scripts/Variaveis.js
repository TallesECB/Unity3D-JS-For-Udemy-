﻿#pragma strict

var inteiro: int;
var numero: float;
var jogador: String;
var vel: float;
var filho: Transform;


function Start () {
	//declarar valores para variaveis
	inteiro = 15;
	numero = numero / inteiro;
	jogador = "Talles Eduardo";
}

function Update () {
	transform.name = jogador;
	transform.Translate(0, 0, vel);
	filho.Rotate(0, vel*50, 0);

}
