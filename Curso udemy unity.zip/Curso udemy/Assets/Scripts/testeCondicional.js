﻿#pragma strict

//var apertou: boolean;
var vel: float;

function Start () {
	vel = 0.3;
}

function Update () {
	//apertou = Input.GetKey("w"); 
	//GetKey verifica se ta apertando ou soltando
	//GetDown verifica se apenas apertou a tecla 
	// if(apertou == true) {
	// 	transform.Translate(0, 0, vel);
	// }
	if(Input.GetKey(KeyCode.W)) {
		transform.Translate(0, 0, vel);
	}
}
