﻿#pragma strict

function Start () {
	//transform.position.x = 20;
	//transform.position.y = 4;
	//transform.position.z = -5;
	//transform.rotation.y = 3;
}

function Update () {
	//transform.Rotate(0, 10, 0);	//x,y,z
	//transform.Translate(0, 0, 0.2); //x,y,z
}
