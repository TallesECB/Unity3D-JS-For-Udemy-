﻿#pragma strict

var vel: float;
var vellateral: float;
var velsubir: float;
var helice: Transform;
var velrotacao: float; 
var rb: Rigidbody;
var velAtual: Vector3;

function Start () {
	rb = GetComponent(Rigidbody);
	
	vel = 50;
	vellateral = 30;
	velsubir = 100;
	velrotacao = 30*Time.deltaTime;
}

function Update () {
	velAtual = velAtual * 0;

	helice.Rotate(0, 500*Time.deltaTime, 0);

	//movimentação profundidade eixo y
	if(Input.GetKey(KeyCode.W)) {
		//transform.Translate(0, 0, vel);
		velAtual = velAtual + vel*transform.forward;
	}
	else {
		if(Input.GetKey(KeyCode.S)) {
			//transform.Translate(0, 0, -vel);
			velAtual = velAtual + (-vel*transform.forward);
		}
	}

	//movimentação lateral eixo x
	if(Input.GetKey(KeyCode.A)) {
		velAtual = velAtual + (-vellateral*transform.right);
	}
	else {
		if(Input.GetKey(KeyCode.D)) {
			velAtual = velAtual + vellateral*transform.right;
		}
	}

	//movimentação para baixo e para cima
	if(Input.GetKey(KeyCode.Space)) {
		velAtual = velAtual + velsubir*transform.up;
	}
	else {
		if(Input.GetKey(KeyCode.Z)) {
			velAtual = velAtual + (-velsubir*transform.up);
		}
	}
  if(Input.GetKey(KeyCode.W) || Input.GetKey(KeyCode.S) || Input.GetKey(KeyCode.A) || Input.GetKey(KeyCode.D))
	rb.velocity = velAtual;

	//rotacionando objeto com o mouse
	if(Input.GetMouseButton(0)) {
		transform.Rotate(0, -velrotacao, 0);
	}
	else {
		if(Input.GetMouseButton(1)) {
			transform.Rotate(0, velrotacao, 0);
		}
	}
}
