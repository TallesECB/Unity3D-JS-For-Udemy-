#pragma strict

var vel: float;
var vellateral: float;
var velsubir: float;
var velrotacao: float; 
var rb: Rigidbody;
var velAtual: Vector3;

function Start () {
	rb = GetComponent(Rigidbody);
	
	vel = 50; // velocidade movimentação w e s 
	vellateral = 30; // velocidade movimentação a e d
	velsubir = 30; // velocidade movimentação space e z
	velrotacao = 30; // velocidade movimentação right click and left click mouse
}

function Update () {
	velAtual = velAtual * 0;


	if(1 == 1) { // if de execução de movimentação inifita para frente
		velAtual = velAtual + vel*transform.forward;
		rb.velocity = velAtual;
	}

	//movimentação lateral eixo x
	if(Input.GetKey(KeyCode.A)) { // if de execução da movimentação para a esquerda 
		velAtual = velAtual + (-vellateral*transform.right);
	}
	else {
		if(Input.GetKey(KeyCode.D)) { // if de execução da movimentação para a direita 
			
			velAtual = velAtual + vellateral*transform.right;
		}
	}

	//movimentação para baixo e para cima
	if(Input.GetKey(KeyCode.Space)) { // if de execução da movimentação para cima
		velAtual = velAtual + velsubir*transform.up;
	}
	else {
		if(Input.GetKey(KeyCode.Z)) { // if de execução da movimentação para baixo
			velAtual = velAtual + (-velsubir*transform.up);
		}
	}

  if(Input.GetKey(KeyCode.A) || Input.GetKey(KeyCode.D) || Input.GetKey(KeyCode.Space) || Input.GetKey(KeyCode.Z) ) {
 		rb.velocity = velAtual; // if de setagem de velocidade para a execução dos movimentos declarados na condição
	}

	//rotacionando objeto com o mouse
	if(Input.GetMouseButton(0)) { // if de execução da movimentação de rotação com o right click
		transform.Rotate(0, -velrotacao, 0);
	}
	else {
		if(Input.GetMouseButton(1)) { // if de execução da movimentação de rotação com o left click
			transform.Rotate(0, velrotacao, 0);
		}
	}
}
